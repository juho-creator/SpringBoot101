package org.example.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.example.domain.Article;


@AllArgsConstructor
@NoArgsConstructor
@Getter
public class ArticleRequest {
    String title;
    String content;

    public Article toEntity(String author){
        return Article.builder()
                .author(author)
                .title(title)
                .content(content)
                .build();
    }
}
