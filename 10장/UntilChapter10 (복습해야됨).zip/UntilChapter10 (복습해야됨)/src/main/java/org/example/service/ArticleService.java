package org.example.service;


import jakarta.transaction.Transactional;
import org.example.dto.ArticleRequest;
import org.example.domain.Article;
import org.example.repository.ArticleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class ArticleService {

    @Autowired
    ArticleRepository articleRepository;


    // Create an article
    public Article save(ArticleRequest request, String userName){
        return articleRepository.save(request.toEntity(userName));
    }


    // Get all articles
    public List<Article> findAll(){
        return articleRepository.findAll();
    }


    // Find an article
    public Article findById(long id){
        return articleRepository.findById(id);

    }

    public void delete(long id){
        Article article = articleRepository.findById(id);

        authorizeArticleAuthor(article);
        articleRepository.delete(article);
    }


    // Update an article
    @Transactional
    public Article updateById(long id, ArticleRequest request){

            // 1. Get existing article
            Article article = articleRepository.findById(id);

            // 2. Get new article
            authorizeArticleAuthor(article);
            article.update(request.getTitle(), request.getContent());

            return article;
    }

    // Delete an article
    public void deleteById(long id){
        articleRepository.deleteById(id);
    }


    // 게시글을 작성한 유저인지 확인
    private static void authorizeArticleAuthor(Article article){
        String userName = SecurityContextHolder.getContext().getAuthentication().getName();

        if (!article.getAuthor().equals(userName)){
            throw new IllegalArgumentException("not authorized");
        }
    }

}
