package org.example.util;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.util.SerializationUtils;

import java.io.Serial;
import java.sql.PreparedStatement;
import java.util.Base64;

public class CookieUtil {
    // 1. 쿠키 생성
    public static void addCookie(HttpServletResponse response, String name, String value, Integer maxAge){
        Cookie cookie = new Cookie(name, value);
        cookie.setMaxAge(maxAge);
        cookie.setPath("/");
        response.addCookie(cookie);
    }

    // 2. 쿠키 삭제
    public static void deleteCookie(HttpServletResponse response, HttpServletRequest request, String name){
        Cookie [] cookies = request.getCookies();

        if (cookies == null){
            return;
        }

        for (Cookie cookie : cookies){
            if (name.equals(cookie.getName())){
                cookie.setPath("/");
                cookie.setMaxAge(0);
                cookie.setValue("");
                response.addCookie(cookie);
            }
        }
    }

    //  객체 -> 쿠키 (직렬화)
    public static String serialize(Object obj){
        return Base64.getUrlEncoder()
                .encodeToString(SerializationUtils.serialize(obj));
    }

    // 쿠키 -> 객체 (역직렬화)
    public static <T> T deserialize(Cookie cookie, Class<T> cls){
        return cls.cast(
                SerializationUtils.deserialize(
                        Base64.getUrlDecoder().decode(cookie.getValue())
                )
        );
    }
}
