package org.example.dto;


import lombok.Getter;
import org.example.domain.Article;

@Getter
public class ArticleResponse {
    String title;
    String content;
    private String author;

    public ArticleResponse(Article article){
        this.title = article.getTitle();
        this.content = article.getContent();
        this.author = article.getAuthor();
    }
}
