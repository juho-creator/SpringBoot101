// 삭제 기능
const deleteBtn = document.getElementById('delete-btn');

if (deleteBtn){
    deleteBtn.addEventListener('click',event =>{
        let id = document.getElementById('article-id').value;

        function success(){
            alert("삭제가 완료되었습니다.");
            location.replace("/articles");
        }

        function fail(){
            alert("삭제 실패했습니다.");
            location.replace("/articles");
        }

        httpRequest("DELETE", "/api/articles/" + id, null, success, fail);
    });
}



// 수정 기능
const updateBtn = document.getElementById('update-btn');

// 수정 기능
if (updateBtn){
    updateBtn.addEventListener('click', event => {
        let params = new URLSearchParams(location.search);
        let id = document.getElementById('article-id').value;

        let body = JSON.stringify({  // ← 변수 선언 필요!
            'title': document.getElementById('article-title').value,
            'content': document.getElementById('article-content').value
        });

        function success(){
            alert("수정 완료되었습니다.");
            location.replace("/articles/" + id);
        }

        function fail(){
            alert("수정 실패했습니다.");
            location.replace("/articles/" + id);
        }

        httpRequest("PUT", "/api/articles/" + id, body, success, fail);
    });
}





const createBtn = document.getElementById('create-btn');

// 생성 기능
if (createBtn){
    createBtn.addEventListener('click', event => {
        let body = JSON.stringify({
            'title': document.getElementById('article-title').value,
            'content': document.getElementById('article-content').value
        });

        function success(){
            alert("등록 완료되었습니다.");
            location.replace("/articles");
        }

        function fail(){
            alert("등록 실패했습니다.");
            location.replace("/articles");
        }

        httpRequest("POST", "/api/articles", body, success, fail);
    });
}


function getCookie(key) {
    var result = null;
    var cookie = document.cookie.split(";");
    cookie.some(function (item) {
        item = item.replace(" ", "");

        var dic = item.split("=");

        if (key === dic[0]){
            result = dic[1];
            return true;
        }
    });

    return result;
}

// HTTP 요청을 보내는 함수
function httpRequest(method, url, body, success, fail){
    fetch(url,{
        method: method,
        headers: {
            Authorization: "Bearer " + localStorage.getItem("access_token"),
            "Content-Type" : "application/json",
        },
        body:body,
    }).then((response)=>{
        if (response.status === 200 || response.status === 201){
            return success();
        }
        const refresh_token = getCookie("refresh_token");
        if (response.status === 401 && refresh_token){
            fetch("/api/token", {
                method: "POST",
                headers:{
                    Authorization: "Bearer " + localStorage.getItem("access_token"),
                    "Content-Type" : "application/json",

                },

                body: JSON.stringify({
                    refreshToken: getCookie("refresh_token"),
                }),
            })
            .then((res) => {
                if (res.ok){
                    return res.json();
                }
            })
            .then((result)=> {
                // 재발급이 성공시 새로운 액세스 토큰으로 교체
                localStorage.setItem("access_token",result.accessToken);
                httpRequest(method, url, body, success, fail);
            })
            .catch((error) => fail());
        } else {
            return fail();
        }
    })
}


